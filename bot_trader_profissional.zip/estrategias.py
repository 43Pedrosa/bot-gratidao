from utils import calcular_rsi, calcular_ema, candle_martelo, candle_engolfo

def verificar_confluencias(df):
    score = 0
    rsi = calcular_rsi(df).iloc[-1]
    ema200 = calcular_ema(df).iloc[-1]
    preco = df['close'].iloc[-1]

    if rsi < 25 or rsi > 75:
        score += 1
    if candle_martelo(df.iloc[-1]) or candle_engolfo(df.iloc[-1]):
        score += 1
    if (preco > ema200 and rsi > 50) or (preco < ema200 and rsi < 50):
        score += 1

    return score >= 3, rsi, preco, ema200