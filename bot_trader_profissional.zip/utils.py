from ta.momentum import RSIIndicator
from ta.trend import EMAIndicator

def calcular_rsi(df, period=14):
    rsi = RSIIndicator(close=df['close'], window=period)
    return rsi.rsi()

def calcular_ema(df, period=200):
    ema = EMAIndicator(close=df['close'], window=period)
    return ema.ema_indicator()

def candle_martelo(candle):
    corpo = abs(candle['close'] - candle['open'])
    sombra_inf = candle['open'] - candle['low'] if candle['close'] > candle['open'] else candle['close'] - candle['low']
    sombra_sup = candle['high'] - candle['close'] if candle['close'] > candle['open'] else candle['high'] - candle['open']
    return sombra_inf > corpo * 2 and sombra_sup < corpo

def candle_engolfo(candle):
    return (candle['close'] > candle['open']) and (candle['open'] < candle['close'])  # Simplificado para exemplo